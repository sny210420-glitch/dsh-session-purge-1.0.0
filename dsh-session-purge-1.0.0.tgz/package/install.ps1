﻿<#
  安装 dsh-session-purge 到指定的 DSH profile。

  用法：
    powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
    powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Profile desktop
    powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -DshHome "D:\other\.dsh"

  脚本做四件事：把插件复制到 <profile>\vendor 与 <profile>\node_modules，
  在 package.json 的 dependencies 里登记 file: 依赖，把插件加入 dsh.profile.bundles，
  最后提示重启 DSH。重复执行是安全的（幂等）。
#>
[CmdletBinding()]
param(
  [string]$Profile = "desktop",
  [string]$DshHome = $env:DSH_HOME
)

$ErrorActionPreference = "Stop"
$PackageName = "dsh-session-purge"

function Fail([string]$Message) {
  Write-Host ""
  Write-Host "安装失败：$Message" -ForegroundColor Red
  exit 1
}

if ([string]::IsNullOrWhiteSpace($DshHome)) {
  $DshHome = Join-Path $env:USERPROFILE ".dsh"
}
$DshHome = [IO.Path]::GetFullPath($DshHome)
if (-not (Test-Path -LiteralPath $DshHome)) { Fail "找不到 DSH_HOME：$DshHome（可以用 -DshHome 指定）" }

$profileDir = Join-Path $DshHome "profiles\$Profile"
if (-not (Test-Path -LiteralPath $profileDir)) {
  $available = @(Get-ChildItem -LiteralPath (Join-Path $DshHome "profiles") -Directory -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name)
  Fail "找不到 profile 目录：$profileDir`n可用 profile：$($available -join ', ')"
}

$manifestPath = Join-Path $profileDir "package.json"
if (-not (Test-Path -LiteralPath $manifestPath)) { Fail "profile 里没有 package.json：$manifestPath" }

# 1. 找到要安装的插件源码：压缩包根目录下的 dsh-session-purge/，或脚本自身所在目录就是插件目录。
$sourceCandidates = @(
  (Join-Path $PSScriptRoot $PackageName),
  $PSScriptRoot
)
$sourceDir = $null
foreach ($candidate in $sourceCandidates) {
  if (Test-Path -LiteralPath (Join-Path $candidate "package.json")) {
    try {
      $candidateName = ([IO.File]::ReadAllText((Join-Path $candidate "package.json"), [Text.Encoding]::UTF8) | ConvertFrom-Json).name
    } catch { $candidateName = $null }
    if ($candidateName -eq $PackageName) { $sourceDir = $candidate; break }
  }
}
if (-not $sourceDir) { Fail "在 $PSScriptRoot 下找不到 $PackageName 的包（需要 package.json 与 lib/）" }

foreach ($required in @("lib\index.js", "lib\client.js", "cordis.patch.yml")) {
  if (-not (Test-Path -LiteralPath (Join-Path $sourceDir $required))) { Fail "插件文件不完整，缺少 $required" }
}
Write-Host "插件来源：$sourceDir"
Write-Host "目标 profile：$profileDir"

# 2. 复制到 vendor 与 node_modules（DSH 从 node_modules 加载，vendor 用于 file: 依赖长期可解析）。
$vendorDir = Join-Path $profileDir "vendor\$PackageName"
$moduleDir = Join-Path $profileDir "node_modules\$PackageName"
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $vendorDir) | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $moduleDir) | Out-Null
foreach ($target in @($vendorDir, $moduleDir)) {
  if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
  Copy-Item -LiteralPath $sourceDir -Destination $target -Recurse -Force
}
Write-Host "已复制插件文件。"

# 3. 更新 profile 清单。
$backupPath = "$manifestPath.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Copy-Item -LiteralPath $manifestPath -Destination $backupPath -Force
Write-Host "已备份原清单：$backupPath"

$manifest = [IO.File]::ReadAllText($manifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
if (-not ($manifest.PSObject.Properties.Name -contains "dependencies") -or $null -eq $manifest.dependencies) {
  $manifest | Add-Member -NotePropertyName "dependencies" -NotePropertyValue ([pscustomobject]@{}) -Force
}
$manifest.dependencies | Add-Member -NotePropertyName $PackageName -NotePropertyValue "file:./vendor/$PackageName" -Force

if (-not ($manifest.PSObject.Properties.Name -contains "dsh") -or $null -eq $manifest.dsh) {
  $manifest | Add-Member -NotePropertyName "dsh" -NotePropertyValue ([pscustomobject]@{}) -Force
}
if (-not ($manifest.dsh.PSObject.Properties.Name -contains "profile") -or $null -eq $manifest.dsh.profile) {
  $manifest.dsh | Add-Member -NotePropertyName "profile" -NotePropertyValue ([pscustomobject]@{}) -Force
}
$bundles = @()
if ($manifest.dsh.profile.PSObject.Properties.Name -contains "bundles" -and $manifest.dsh.profile.bundles) {
  $bundles = @($manifest.dsh.profile.bundles)
}
if ($bundles -notcontains $PackageName) { $bundles += $PackageName }
$manifest.dsh.profile | Add-Member -NotePropertyName "bundles" -NotePropertyValue $bundles -Force

$json = $manifest | ConvertTo-Json -Depth 32
[IO.File]::WriteAllText($manifestPath, $json, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "已登记依赖与 bundle。"

# 4. 安装结果自检。
foreach ($target in @(
  (Join-Path $moduleDir "lib\index.js"),
  (Join-Path $moduleDir "lib\client.js"),
  (Join-Path $vendorDir "cordis.patch.yml")
)) {
  if (-not (Test-Path -LiteralPath $target)) { Fail "写入后校验失败，缺少 $target" }
}
$check = [IO.File]::ReadAllText($manifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
if (-not ($check.dependencies.PSObject.Properties.Name -contains $PackageName)) { Fail "清单里没有 dependencies.$PackageName" }
if (@($check.dsh.profile.bundles) -notcontains $PackageName) { Fail "清单里没有 dsh.profile.bundles.$PackageName" }

Write-Host ""
Write-Host "安装完成 ✅" -ForegroundColor Green
Write-Host "请完全退出并重新打开 DSH 桌面端，然后归档一个对话，在它的「⋯」菜单里就能看到「删除对话…」。"