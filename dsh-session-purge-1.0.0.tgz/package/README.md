# dsh-session-purge

Delete **archived** DSH sessions from the sidebar, in two tiers. Tier 2 is a
strict superset of tier 1 — picking it performs the complete deletion in one
action; you never run tier 1 first.

| Tier | Removes | Keeps |
| --- | --- | --- |
| 1 · 只删对话 | session JSONL directory, projection-cache rows, every `$DSH_HOME/storages` record named after the session id, archived/pinned/workspace bookkeeping | attachments, spill files, deliverables |
| 2 · 完全删除 | **everything tier 1 removes**, plus the artifacts marked in the dialog: attachment objects no other session references, leftover attachment objects whose conversation is already gone, `session-<sha256(id)[:12]>` spill dirs, files the session presented, and files the session created in its project directory | any artifact you untick in the dialog, other sessions' data |

In the tier 2 dialog every artifact has a checkbox, grouped into **对话记录**
(always deleted) and **对话产物** (one row per file: attachments, spill files,
deliverables, session-created documents such as `.docx/.pptx/.pdf`). Documents,
media and DSH-owned objects start ticked; source code or other files outside
DSH_HOME start unticked, so ticking one is the explicit consent to delete it.
Unticked rows are reported back in `skipped`.

Why a plugin: DSH's JSONL persistence seam has no delete API (`dsh-session-persistence-jsonl` README: 「不删除会话文件…seam 无删除接口」) and the workspace registry only archives. This plugin owns the removal end to end.

## Where the button is

Sidebar → Workspaces → session row menu (⋯) on a **visible archived** row → 「删除对话…」, directly after the archive/unarchive item (`order: 500`). Non-archived rows get no entry.

## Install

### From the release zip (Windows, one command)

Unzip, open PowerShell in that folder, run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

It copies the package into `<profile>\vendor` and `<profile>\node_modules`, registers the
`file:` dependency and appends the package to `dsh.profile.bundles`, backing up the old
`package.json` first. Add `-Profile <name>` (default `desktop`) or `-DshHome <path>` if needed.
Restart the Desktop app afterwards — the host plugin and the client bundle both load at boot.

### From the npm tarball

```powershell
dsh plugin --profile desktop add "file:C:\path\to\dsh-session-purge-1.0.0.tgz"
```

### Manual

Copy the package to `<profile>\node_modules\dsh-session-purge` (and to `<profile>\vendor\dsh-session-purge`
if you want the `file:` dependency to stay resolvable), set
`"dsh-session-purge": "file:./vendor/dsh-session-purge"` in `dependencies`, append
`"dsh-session-purge"` to `dsh.profile.bundles`, then restart.

`cordis.patch.yml` ships with the package, so listing it in `dsh.profile.bundles` is enough — the bundle patch inserts the plugin. Do not also edit `cordis.yml` / `cordis.patch.yml` by hand (a duplicate id breaks the loader).

## Dry run

```powershell
node "<source>\scripts\dry-run.mjs" session-xxxxxxxx --home "$env:DSH_HOME"
```

Prints the tier 1 / tier 2 file list and byte totals without touching anything.

## Cleaning up after an earlier tier 1 delete

Tier 1 keeps attachments on purpose, so they become unreachable once their
conversation is gone. Tier 2 now sweeps those leftovers automatically; to clear
a backlog without deleting another conversation:

```powershell
node "<source>\scripts\sweep-orphans.mjs" --home "$env:DSH_HOME"          # dry run
node "<source>\scripts\sweep-orphans.mjs" --home "$env:DSH_HOME" --apply  # delete
```

It only touches `attachments/v1/objects/<xx>/<sha256>` and the matching
`attachments/v1/files` entries whose digest no surviving session log mentions.

## Files a conversation created

A Word/Excel/PDF file produced by a script never appears in `deliverables/presented`, so tier 2 scans the session's own project folder (the `cwd` in the JSONL header, two levels deep) for documents and media whose creation time falls inside the session window.

- **Listed**: every `.docx .xlsx .pptx .pdf .png .mp4 .zip …` born while the session ran — so the dialog can offer a checkbox even when the log never mentions the file.
- **Pre-ticked**: only when the conversation itself names that file in a `tool/call` argument (a script whose output path is written in the code, a `write` call, a `present`ed deliverable). An unnamed document in the project folder may just as well be the user's own, so it starts unticked.
- **Never listed**: files outside the project folder (except `present`ed deliverables), the drive root, the host install, the user profile — a log line quoting a path is not ownership.

Ticked rows are the only files tier 2 removes outside DSH_HOME.

## Safety rules

- Only archived sessions are accepted (`409 not-archived` otherwise).
- A session with a **running turn** no longer blocks the delete: the plugin cancels queued activity (`stopSessionActivity`) and polls the agent status briefly first. Only a log the kernel truly refuses to release still answers `409 live`, which means a turn is mid-append — retry a moment later.
- Every path is resolved and must stay inside its allowed root (sessions root, `$DSH_HOME/storages`, `$DSH_HOME/attachments`, the discovered `dsh-spill-*` dir, or the session's own project folder). A path whose parent is a drive root or a system tree is refused outright.
- Attachment objects are removed only when **no surviving session** references the same `sha256`; unreadable sibling logs make the plugin skip attachments entirely. Tier 2 also sweeps objects left behind by earlier deletes (`kind: orphan-attachment`), so repeated deletions converge on zero residual bytes.
- Deleting the conversation emits `api-session/removed`, so the sidebar row disappears without a reload.
- Deletion is irreversible — the dialog requires an explicit confirmation checkbox.

## Routes

- `GET /dsh-session-purge/plan?sessionId=…` → `{session, tier1[], artifacts[], tier2[], totals, warnings}`
  - `tier1` = the conversation records; `artifacts` = what the conversation produced;
    `tier2` = `tier1 + artifacts` (the complete deletion set), and `totals.tier2Bytes = totals.tier1Bytes + totals.artifactsBytes`.
- `POST /dsh-session-purge/delete` `{sessionId, tier: 1|2, paths?: string[], confirm: true}` → `{ok, freedBytes, removed[], skipped[], failures[]}`
  - `tier: 2` removes the whole `tier2` set in that one call.
  - `paths` is the dialog's checkbox selection: only those artifacts are deleted (the conversation records are always removed by tier 2). Omit `paths` to fall back to the defaults; unticked entries are returned in `skipped`.

Both are same-origin, `no-store`, and behind the host connection gate on non-Desktop runtimes.

## Configuration

| Key | Default | Meaning |
| --- | --- | --- |
| `dshHome` | `$DSH_HOME` or `~/.dsh` | storage root |
| `sessionRoot` | `sessionPersistence.root` | override the sessions directory |
| `spillRoots` | every `<tmp>/dsh-spill-*` | where spill files live |

## Uninstall

Delete `node_modules/dsh-session-purge`, remove the entry from `dependencies` and `dsh.profile.bundles`, restart.