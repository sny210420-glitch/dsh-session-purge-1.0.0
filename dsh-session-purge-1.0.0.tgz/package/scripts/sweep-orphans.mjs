/**
 * Remove attachment objects that no surviving conversation references.
 *
 *   node scripts/sweep-orphans.mjs                # dry run, prints what it would free
 *   node scripts/sweep-orphans.mjs --apply        # actually deletes
 *   node scripts/sweep-orphans.mjs --home <dir>   # override DSH_HOME
 *
 * Tier 2 of the plugin now sweeps these automatically; this script exists for
 * cleaning up whatever an earlier tier 1 delete left behind.
 */
import { rm } from 'node:fs/promises'
import { join } from 'node:path'
import { buildOrphanSweep, isInside, resolveDshHome } from '../lib/plan.js'

const argv = process.argv.slice(2)
const homeIndex = argv.indexOf('--home')
const home = resolveDshHome(homeIndex === -1 ? undefined : argv[homeIndex + 1])
const apply = argv.includes('--apply')

const sweep = await buildOrphanSweep({ home, sessionsRoot: join(home, 'sessions') })

console.log(`DSH_HOME  ${home}`)
console.log(`orphans   ${sweep.entries.length} item(s), ${sweep.files} file(s)`)
for (const entry of sweep.entries) {
  console.log(`  ${entry.kind.padEnd(22)} ${entry.bytes.toLocaleString('en-US').padStart(12)} B  ${entry.path}`)
}
for (const warning of sweep.warnings) console.log(`warning: ${warning}`)
console.log(`total     ${sweep.bytes.toLocaleString('en-US')} B`)

if (!apply) {
  console.log('\ndry run — re-run with --apply to delete these files')
  process.exit(0)
}

let freed = 0
const failures = []
for (const entry of sweep.entries) {
  if (!isInside(entry.path, entry.root)) {
    failures.push({ path: entry.path, error: 'path escaped its allowed root' })
    continue
  }
  try {
    await rm(entry.path, { recursive: true, force: true, maxRetries: 3, retryDelay: 120 })
    freed += entry.bytes
  } catch (error) {
    failures.push({ path: entry.path, error: String(error?.message ?? error) })
  }
}

console.log(`\nremoved ${sweep.entries.length - failures.length}/${sweep.entries.length} item(s), freed ${freed.toLocaleString('en-US')} B`)
for (const failure of failures) console.log(`  failed ${failure.path}: ${failure.error}`)
process.exit(failures.length === 0 ? 0 : 1)