#!/usr/bin/env node
/**
 * 生成 DSH 插件市场索引（format 1）。
 *
 * 市场不是上传站：DSH 读取你配置的索引 URL，索引里写明每个插件每个版本从哪里安装（npm 或 git）。
 * 所以「上架」= 把包发到 npm 或推到 GitHub + 托管一份本脚本生成的 index.json。
 *
 *   node scripts/make-index.mjs --source npm
 *   node scripts/make-index.mjs --source git --repo https://github.com/you/dsh-session-purge --commit <40位commit>
 *
 * 其它参数：--version 1.0.0 --published <unix秒> --out market/index.json
 *          --title-zh --title-en --desc-zh --desc-en --author --homepage
 */
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const argv = process.argv.slice(2);
function flag(name, fallback) {
  const at = argv.indexOf(`--${name}`);
  if (at === -1) return fallback;
  const value = argv[at + 1];
  if (value === undefined || value.startsWith('--')) throw new Error(`--${name} 需要一个值`);
  return value;
}
const has = (name) => argv.includes(`--${name}`);

const pkg = JSON.parse(
  await import('node:fs').then((fs) => fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8')),
);

const sourceKind = flag('source', 'npm');
const version = flag('version', pkg.version);
const published = Number(flag('published', Math.floor(Date.now() / 1000)));
const out = resolve(flag('out', 'market/index.json'));

const titleZh = flag('title-zh', '已归档对话删除');
const titleEn = flag('title-en', 'Archived conversation purge');
const descZh = flag(
  'desc-zh',
  '给已归档的 DSH 对话加一个真正的删除入口：档 1 只删对话记录，档 2 连它产生的附件与文件一起删干净。',
);
const descEn = flag(
  'desc-en',
  'A real delete entry for archived DSH conversations: tier 1 removes the conversation, tier 2 removes everything it produced.',
);

let source;
if (sourceKind === 'npm') {
  source = { type: 'npm' };
  const registry = flag('registry', undefined);
  if (registry) source.registry = registry;
} else if (sourceKind === 'git') {
  const repo = flag('repo', undefined);
  if (!repo) throw new Error('--source git 需要 --repo <https URL>');
  const commit = flag('commit', undefined);
  if (!commit || !/^[0-9a-f]{40}$/.test(commit)) throw new Error('--source git 需要 40 位小写十六进制 --commit');
  source = { type: 'git', url: repo, commit };
  const sub = flag('path', undefined);
  if (sub) source.path = sub;
} else {
  throw new Error('--source 只能是 npm 或 git');
}

const index = {
  format: 1,
  title: { en: 'dsh-session-purge', zh: 'DSH 已归档对话删除' },
  description: {
    en: 'Delete archived DSH conversations and everything they produced.',
    zh: '删除已归档的 DSH 对话，以及它们产生的全部产物。',
  },
  metadata: {
    categories: {
      maintenance: { title: { en: 'Maintenance', zh: '维护工具' } },
      storage: { title: { en: 'Storage', zh: '存储清理' } },
    },
    labels: {
      destructive: { title: { en: 'Destructive', zh: '破坏性操作' } },
      'zh-CN': { title: { en: 'Chinese UI', zh: '中文界面' } },
    },
    sortKeys: {
      added: { title: { en: 'Added', zh: '上架时间' }, order: 'desc' },
    },
  },
  plugins: [
    {
      name: pkg.name,
      title: { en: titleEn, zh: titleZh },
      description: { en: descEn, zh: descZh },
      author: flag('author', pkg.author ?? ''),
      homepage: flag('homepage', undefined),
      metadata: {
        category: 'storage',
        keywords: ['session', 'archive', 'delete', 'cleanup', 'disk', '对话', '归档', '删除'],
        labels: ['destructive', 'zh-CN'],
        sortKeys: { added: published },
      },
      versions: [
        {
          version,
          publishTimestamp: published,
          source,
        },
      ],
    },
  ],
};

// homepage 为空时删掉，避免校验器把它当成空字符串拒绝。
if (!index.plugins[0].homepage) delete index.plugins[0].homepage;
if (!index.plugins[0].author) delete index.plugins[0].author;

mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, `${JSON.stringify(index, null, 2)}\n`, 'utf8');
console.log(`写入 ${out}`);
console.log(JSON.stringify(index.plugins[0].versions[0], null, 2));