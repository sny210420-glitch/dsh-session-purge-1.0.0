#!/usr/bin/env node
/**
 * Print every planned entry with its preselection flag, for one session.
 *
 *   node scripts/show-plan.mjs <session-id>
 */
import { buildPlan, resolveDshHome } from '../lib/plan.js'

const sessionId = process.argv[2]
if (!sessionId) {
  console.error('usage: node scripts/show-plan.mjs <session-id>')
  process.exit(2)
}
const plan = await buildPlan({ sessionId, home: resolveDshHome() })
const mark = (entry) => (entry.auto === true ? 'AUTO' : '    ') + (entry.external === true ? ' EXT' : '    ')
for (const entry of plan.tier1) console.log(mark(entry), entry.kind.padEnd(18), entry.path)
for (const entry of plan.artifacts) console.log(mark(entry), entry.kind.padEnd(18), entry.path)
console.log('totals', JSON.stringify(plan.totals))