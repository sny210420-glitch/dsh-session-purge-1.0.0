#!/usr/bin/env node
/**
 * Offline self-test for the host routes: builds a throwaway DSH_HOME, then
 * drives the real handlers (plan → delete tier 1 → delete tier 2) through a
 * fake cordis context. Nothing outside the temp dir is touched.
 *
 *   node scripts/test-routes.mjs
 */
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdir, rm, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Readable } from 'node:stream'
import { zstdCompressSync } from 'node:zlib'
import { apply } from '../lib/index.js'
import { collectTouchedPaths, spillDirName } from '../lib/plan.js'

const here = dirname(fileURLToPath(import.meta.url))
const home = join(here, '..', '.tmp-test')
const sessionsRoot = join(home, 'sessions')
// Pretend project directory, outside DSH_HOME: files the conversation created.
const projectDir = join(here, '..', '.tmp-project')
// One project directory per pick-test session, so their scans cannot overlap.
const projectDirA = join(here, '..', '.tmp-project-a')
const projectDirB = join(here, '..', '.tmp-project-b')

const sharedBody = 'shared-image-bytes'
const exclusiveBody = 'exclusive-image-bytes'
const thirdBody = 'third-image-bytes'
// Residue from an earlier tier 1 delete: on disk, cited by no log.
const orphanBody = 'orphan-image-bytes'
const pickA = 'pick-a-image-bytes'
const pickB = 'pick-b-image-bytes'
const sharedHex = createHash('sha256').update(sharedBody).digest('hex')
const exclusiveHex = createHash('sha256').update(exclusiveBody).digest('hex')
const thirdHex = createHash('sha256').update(thirdBody).digest('hex')
const orphanHex = createHash('sha256').update(orphanBody).digest('hex')
const pickAHex = createHash('sha256').update(pickA).digest('hex')
const pickBHex = createHash('sha256').update(pickB).digest('hex')

async function writeLog(sessionId, lines, cwd = 'E:\\tmp') {
  const dir = join(sessionsRoot, '--tmp--', sessionId)
  await mkdir(dir, { recursive: true })
  const header = { type: 'session', version: 4, id: sessionId, createdAt: '2026-01-01T00:00:00.000Z', cwd }
  const body = [header, ...lines].map((line) => JSON.stringify(line)).join('\n') + '\n'
  await writeFile(join(dir, 'session.v4.jsonl.zstd'), zstdCompressSync(Buffer.from(body, 'utf8')))
}

function fakeResponse() {
  const state = { status: 0, headers: {}, text: '' }
  return {
    state,
    writeHead(status, headers) {
      state.status = status
      Object.assign(state.headers, headers ?? {})
    },
    end(chunk) {
      if (chunk !== undefined) state.text += String(chunk)
    },
  }
}

function fakeRequest(method, url, body) {
  const request = Readable.from(body === undefined ? [] : [Buffer.from(JSON.stringify(body))])
  request.method = method
  request.url = url
  request.headers = body === undefined ? {} : { 'content-type': 'application/json' }
  return request
}

async function invoke(routes, method, url, body) {
  const route = routes.find((entry) => entry.path === url.split('?')[0])
  assert.ok(route, `route ${url} not registered`)
  const response = fakeResponse()
  await route.handler(fakeRequest(method, url, body), response)
  return { status: response.state.status, body: response.state.text === '' ? null : JSON.parse(response.state.text) }
}

await rm(home, { recursive: true, force: true })
await mkdir(sessionsRoot, { recursive: true })

const archived = ['session-test-0001', 'session-test-0003', 'session-test-0004', 'session-test-0005', 'session-test-0006']
const members = ['session-test-0001', 'session-test-0002', 'session-test-0003', 'session-test-0004', 'session-test-0005', 'session-test-0006']
const events = []
const detached = []
// Sessions with a turn in flight: the only thing that blocks deletion.
const running = new Set()

await writeLog('session-test-0001', [
  { type: 'user/message', data: { text: 'look', attachment: { attachmentId: `sha256:${exclusiveHex}` } } },
  { type: 'deliverables/presented', data: { turn: 1, files: [{ path: join(home, 'report.txt'), description: 'x' }] } },
])
await writeLog('session-test-0002', [
  { type: 'user/message', data: { text: 'look', attachment: { attachmentId: `sha256:${sharedHex}` } } },
])
await writeLog('session-test-0003', [
  { type: 'user/message', data: { text: 'look', attachment: { attachmentId: `sha256:${thirdHex}` } } },
  {
    type: 'tool/call',
    data: {
      turn: 1,
      step: 1,
      callId: 'call-doc',
      name: 'write',
      arguments: JSON.stringify({ file_path: join(projectDir, 'notes.docx'), content: 'docx-bytes' }),
    },
  },
  {
    type: 'tool/call',
    data: {
      turn: 1,
      step: 2,
      callId: 'call-notes',
      name: 'write',
      arguments: JSON.stringify({ file_path: join(projectDir, 'notes.js'), content: 'console.log(1)' }),
    },
  },
  { type: 'assistant/message', data: { text: 'wrote notes.docx and notes.js into the project directory' } },
], projectDir)

await rm(projectDir, { recursive: true, force: true })
await mkdir(projectDir, { recursive: true })
await writeFile(join(projectDir, 'notes.docx'), 'docx-bytes')
await writeFile(join(projectDir, 'notes.js'), 'console.log(1)')

// Two sessions that each produced one document plus one attachment, used to
// exercise the per-artifact checkboxes (keep everything / delete just the doc).
for (const [sessionId, dir, hex, body] of [
  ['session-test-0004', projectDirA, pickAHex, pickA],
  ['session-test-0005', projectDirB, pickBHex, pickB],
]) {
  await writeLog(sessionId, [
    { type: 'user/message', data: { text: 'look', attachment: { attachmentId: `sha256:${hex}` } } },
    {
      type: 'tool/call',
      data: { turn: 1, step: 1, callId: 'call-brief', name: 'write', arguments: JSON.stringify({ file_path: join(dir, 'brief.docx') }) },
    },
    { type: 'assistant/message', data: { text: 'wrote brief.docx into the project directory' } },
  ], dir)
  await rm(dir, { recursive: true, force: true })
  await mkdir(dir, { recursive: true })
  await writeFile(join(dir, 'brief.docx'), body)
}

for (const [hex, body] of [[exclusiveHex, exclusiveBody], [sharedHex, sharedBody], [thirdHex, thirdBody], [orphanHex, orphanBody], [pickAHex, pickA], [pickBHex, pickB]]) {
  const objectPath = join(home, 'attachments', 'v1', 'objects', hex.slice(0, 2), hex)
  await mkdir(dirname(objectPath), { recursive: true })
  await writeFile(objectPath, body)
}
await mkdir(join(home, 'storages', 'session_projcache', 'sessions'), { recursive: true })
await mkdir(join(home, 'storages', 'vision_router_session_policy', 'policies'), { recursive: true })
for (const id of ['session-test-0001', 'session-test-0002', 'session-test-0003', 'session-test-0004', 'session-test-0005', 'session-test-0006']) {
  await writeFile(join(home, 'storages', 'session_projcache', 'sessions', `${id}.json`), '{"version":1,"record":{}}')
  await writeFile(join(home, 'storages', 'vision_router_session_policy', 'policies', `${id}.json`), '{}')
}
await writeFile(join(home, 'report.txt'), 'deliverable')
const spillDir = join(home, 'spill', spillDirName('session-test-0001'))
await mkdir(spillDir, { recursive: true })
await writeFile(join(spillDir, 'blob.txt'), 'spill')

// A script wrote a document into the session's project directory; the file
// name itself never appears in the log, so it is listed but not preselected.
const strayDir = join(here, '..', '.tmp-project-c')
await writeLog('session-test-0006', [
  {
    type: 'tool/call',
    data: {
      turn: 1,
      step: 1,
      callId: 'call-1',
      name: 'pwsh',
      arguments: JSON.stringify({ command: `python "${join(strayDir, 'make_doc.py')}"` }),
    },
  },
  { type: 'tool/result', data: { turn: 1, step: 1, callId: 'call-1', content: 'ok' } },
], strayDir)
await rm(strayDir, { recursive: true, force: true })
await mkdir(strayDir, { recursive: true })
await writeFile(join(strayDir, '季度报告.docx'), 'docx from a script')

// A canary outside every directory the log names must never be planned, even
// when it is created while the session runs.
const canaryDir = join(here, '..', '.tmp-canary')
await rm(canaryDir, { recursive: true, force: true })
await mkdir(canaryDir, { recursive: true })
await writeFile(join(canaryDir, '别删我.docx'), 'not mine')

// Only tool calls count as ownership evidence; a header cwd or an assistant
// message quoting a path must never turn a host file into a delete target.
const headerOnly = JSON.stringify({ type: 'session', cwd: 'E:\\tmp', id: 'session-x' })
assert.deepEqual([...collectTouchedPaths(headerOnly)], [], 'header cwd is not a candidate')
const plainMessage = JSON.stringify({ type: 'assistant/message', data: { text: 'see E:\\out\\make.py' } })
assert.deepEqual([...collectTouchedPaths(plainMessage)], [], 'a message is not a tool call')
const quoted = `${JSON.stringify({ type: 'session', cwd: 'E:\\tmp', id: 'session-x' })}\n${JSON.stringify({ type: 'tool/call', data: { arguments: JSON.stringify({ command: 'python "E:\\out\\make.py"' }) } })}`
assert.deepEqual([...collectTouchedPaths(quoted)], ['E:\\out\\make.py'], 'quoted path is unescaped')

const routes = []
const host = {
  get(name) {
    return name === 'webServer' ? host.webServer : undefined
  },
  effect(fn) {
    fn()
  },
  webServer: {
    register(route) {
      routes.push(route)
      return () => {}
    },
  },
  // A closed panel still leaves an entry in the session store; that must NOT
  // count as "open", so the fake always returns one.
  sessions: { get: () => ({ id: 'still-in-store' }) },
  agents: { get: (id) => (running.has(id) ? { status: 'running' } : { status: 'idle' }) },
  sessionPersistence: { root: sessionsRoot },
  workspaceRegistry: {
    archivedSessionIds: archived,
    async unarchiveSession(id) {
      const index = archived.indexOf(id)
      if (index !== -1) archived.splice(index, 1)
    },
    async unpinSession() {},
    list() {
      return [{
        sessionIds: [...members],
        async detachSession(id) {
          detached.push(id)
        },
      }]
    },
  },
  emit(name, payload) {
    events.push([name, payload])
  },
}
const ctx = {
  get(name) {
    return name === 'webServer' ? host.webServer : undefined
  },
  inject(_deps, callback) {
    callback(host)
  },
}

apply(ctx, { dshHome: home, sessionRoot: sessionsRoot, spillRoots: [join(home, 'spill')] })

// --- plan ---------------------------------------------------------------
const plan = await invoke(routes, 'GET', '/dsh-session-purge/plan?sessionId=session-test-0001')
assert.equal(plan.status, 200, plan.body && JSON.stringify(plan.body))
assert.equal(plan.body.tier1.length, 3, 'log dir + 2 id records')
assert.ok(
  plan.body.tier2.some((entry) => entry.kind === 'attachment' && entry.path.endsWith(exclusiveHex)),
  `exclusive attachment missing from tier 2: ${JSON.stringify(plan.body.tier2)}`,
)
assert.ok(!plan.body.tier2.some((entry) => entry.path.endsWith(sharedHex)), 'shared attachment must be kept')
// Leftovers from earlier deletes are swept by tier 2 as well, so repeated
// deletions converge on zero residual bytes.
assert.ok(
  plan.body.tier2.some((entry) => entry.kind === 'orphan-attachment' && entry.path.endsWith(orphanHex)),
  'orphaned attachment must be part of the tier 2 footprint',
)
assert.ok(plan.body.tier2.some((entry) => entry.kind === 'spill'))
assert.ok(plan.body.tier2.some((entry) => entry.kind === 'deliverable'))
// Tier 2 is the COMPLETE deletion: a strict superset of tier 1, executed in one call.
assert.equal(plan.body.tier2.length, plan.body.tier1.length + plan.body.artifacts.length, 'tier 2 = tier 1 + artifacts')
for (const entry of plan.body.tier1) {
  assert.ok(
    plan.body.tier2.some((candidate) => candidate.kind === entry.kind && candidate.path === entry.path),
    `tier 2 must contain tier 1 entry ${entry.path}`,
  )
}
assert.equal(plan.body.totals.tier2Bytes, plan.body.totals.tier1Bytes + plan.body.totals.artifactsBytes)
assert.ok(plan.body.totals.tier2Bytes > plan.body.totals.tier1Bytes, 'tier 2 must free more than tier 1')

const refusedPlan = await invoke(routes, 'GET', '/dsh-session-purge/plan?sessionId=session-test-0002')
assert.equal(refusedPlan.status, 409, 'unarchived session must be refused')
assert.equal(refusedPlan.body.error, 'not-archived')

// --- tier 1 -------------------------------------------------------------
const tier1 = await invoke(routes, 'POST', '/dsh-session-purge/delete', {
  sessionId: 'session-test-0001',
  tier: 1,
  confirm: true,
})
assert.equal(tier1.status, 200, JSON.stringify(tier1.body))
assert.equal(existsSync(join(sessionsRoot, '--tmp--', 'session-test-0001')), false, 'log dir removed')
assert.equal(existsSync(join(home, 'storages', 'session_projcache', 'sessions', 'session-test-0001.json')), false)
assert.equal(existsSync(join(home, 'storages', 'vision_router_session_policy', 'policies', 'session-test-0001.json')), false)
assert.equal(existsSync(join(home, 'attachments', 'v1', 'objects', exclusiveHex.slice(0, 2), exclusiveHex)), true, 'tier 1 must keep attachments')
assert.equal(existsSync(join(home, 'attachments', 'v1', 'objects', orphanHex.slice(0, 2), orphanHex)), true, 'tier 1 must not sweep orphans')
assert.equal(existsSync(join(spillDir, 'blob.txt')), true, 'tier 1 must keep spill')
assert.equal(existsSync(join(home, 'report.txt')), true, 'tier 1 must keep deliverables')
assert.deepEqual(detached, ['session-test-0001'], 'workspace bookkeeping dropped')
assert.deepEqual(events, [['api-session/removed', 'session-test-0001']])

// --- tier 2 -------------------------------------------------------------
// A document the conversation created in its project directory is part of the
// default tier 2 footprint even though it lives outside DSH_HOME.
const plan3 = await invoke(routes, 'GET', '/dsh-session-purge/plan?sessionId=session-test-0003')
assert.equal(plan3.status, 200)
const docxEntry = plan3.body.tier2.find((entry) => entry.kind === 'session-file' && entry.path.endsWith('notes.docx'))
assert.ok(docxEntry, `session-created document missing: ${JSON.stringify(plan3.body.tier2)}`)
assert.equal(docxEntry.external, true)
assert.equal(docxEntry.auto, true)
const jsEntry = plan3.body.tier2.find((entry) => entry.kind === 'session-file' && entry.path.endsWith('notes.js'))
assert.ok(jsEntry, 'code files are listed too, so the dialog can offer them')
assert.equal(jsEntry.auto, false, 'code outside DSH_HOME is not preselected')

const tier2 = await invoke(routes, 'POST', '/dsh-session-purge/delete', {
  sessionId: 'session-test-0003',
  tier: 2,
  confirm: true,
})
assert.equal(tier2.status, 200, JSON.stringify(tier2.body))
// One tier 2 call removes the conversation records AND the artifacts together.
assert.equal(existsSync(join(sessionsRoot, '--tmp--', 'session-test-0003')), false)
assert.equal(existsSync(join(home, 'storages', 'session_projcache', 'sessions', 'session-test-0003.json')), false, 'tier 2 also removes conversation records')
assert.equal(tier2.body.tier, 2)
assert.ok(tier2.body.removed.some((entry) => entry.includes('session-test-0003')), 'conversation dir reported removed')
assert.ok(tier2.body.freedBytes > 0)
assert.equal(existsSync(join(home, 'attachments', 'v1', 'objects', thirdHex.slice(0, 2), thirdHex)), false, 'exclusive attachment removed')
assert.equal(existsSync(join(home, 'attachments', 'v1', 'objects', exclusiveHex.slice(0, 2), exclusiveHex)), false, 'orphaned attachment swept')
assert.equal(existsSync(join(home, 'attachments', 'v1', 'objects', orphanHex.slice(0, 2), orphanHex)), false, 'orphaned attachment swept')
assert.equal(existsSync(join(home, 'attachments', 'v1', 'objects', sharedHex.slice(0, 2), sharedHex)), true, 'shared attachment kept')
assert.equal(existsSync(join(projectDir, 'notes.docx')), false, 'document produced by the conversation removed with tier 2')
assert.equal(existsSync(join(projectDir, 'notes.js')), true, 'code file kept unless opted in')

// --- per-artifact pick --------------------------------------------------
// The dialog sends the ticked paths; tier 2 then deletes exactly those, plus
// the conversation records that tier 2 always removes.
const plan4 = await invoke(routes, 'GET', '/dsh-session-purge/plan?sessionId=session-test-0004')
assert.equal(plan4.status, 200)
const briefA = plan4.body.tier2.find((entry) => entry.kind === 'session-file' && entry.path.endsWith('brief.docx'))
assert.ok(briefA, `created document must be listed so it can be ticked: ${JSON.stringify(plan4.body.tier2)}`)
assert.equal(briefA.auto, true)

const keepAll = await invoke(routes, 'POST', '/dsh-session-purge/delete', {
  sessionId: 'session-test-0004',
  tier: 2,
  paths: [],
  confirm: true,
})
assert.equal(keepAll.status, 200, JSON.stringify(keepAll.body))
assert.equal(existsSync(join(sessionsRoot, '--tmp--', 'session-test-0004')), false, 'conversation records always go')
assert.equal(existsSync(join(projectDirA, 'brief.docx')), true, 'unticked document kept')
assert.equal(existsSync(join(home, 'attachments', 'v1', 'objects', pickAHex.slice(0, 2), pickAHex)), true, 'unticked attachment kept')
assert.ok(keepAll.body.skipped.some((path) => path.endsWith('brief.docx')), 'skipped artifacts are reported')

const plan5 = await invoke(routes, 'GET', '/dsh-session-purge/plan?sessionId=session-test-0005')
const briefB = plan5.body.tier2.find((entry) => entry.kind === 'session-file' && entry.path.endsWith('brief.docx'))
const docOnly = await invoke(routes, 'POST', '/dsh-session-purge/delete', {
  sessionId: 'session-test-0005',
  tier: 2,
  paths: [briefB.path],
  confirm: true,
})
assert.equal(docOnly.status, 200, JSON.stringify(docOnly.body))
assert.equal(existsSync(join(projectDirB, 'brief.docx')), false, 'ticked document removed')
assert.equal(existsSync(join(home, 'attachments', 'v1', 'objects', pickBHex.slice(0, 2), pickBHex)), true, 'only the ticked artifact goes')

// --- documents written by a script --------------------------------------
// The file name never appears in the log. The document is still listed so the
// user can tick it, but it is not preselected: an unnamed file in the project
// folder may just as well be the user's own.
const plan6 = await invoke(routes, 'GET', '/dsh-session-purge/plan?sessionId=session-test-0006')
assert.equal(plan6.status, 200, JSON.stringify(plan6.body))
const reportEntry = plan6.body.tier2.find((entry) => entry.kind === 'session-file' && entry.path.endsWith('季度报告.docx'))
assert.ok(reportEntry, `script-written document missing: ${JSON.stringify(plan6.body.tier2)}`)
assert.equal(reportEntry.auto, false, 'unnamed documents are listed but opt-in')
const plannedPaths = plan6.body.tier2.map((entry) => entry.path)
assert.equal(plannedPaths.some((path) => path.includes('别删我')), false, 'files outside the session project stay out of the plan')
assert.equal(plannedPaths.some((path) => path.includes('Myself-工作')), false, 'a drive root is never scanned')
const removeReport = await invoke(routes, 'POST', '/dsh-session-purge/delete', {
  sessionId: 'session-test-0006',
  tier: 2,
  paths: [reportEntry.path],
  confirm: true,
})
assert.equal(removeReport.status, 200, JSON.stringify(removeReport.body))
assert.equal(existsSync(join(strayDir, '季度报告.docx')), false, 'script-written document removed')

// --- archive then delete -------------------------------------------------
// A session-store entry must never block deletion, and a running turn is
// cancelled by the host before files go — so archiving and deleting in one go
// works without reopening the conversation.
archived.push('session-test-0002')
running.add('session-test-0002')
const afterArchive = await invoke(routes, 'POST', '/dsh-session-purge/delete', {
  sessionId: 'session-test-0002',
  tier: 1,
  confirm: true,
})
assert.equal(afterArchive.status, 200, JSON.stringify(afterArchive.body))
assert.equal(existsSync(join(sessionsRoot, '--tmp--', 'session-test-0002')), false, 'delete works right after archiving')
running.delete('session-test-0002')

// --- guards -------------------------------------------------------------
const missingConfirm = await invoke(routes, 'POST', '/dsh-session-purge/delete', { sessionId: 'session-test-0002', tier: 1 })
assert.equal(missingConfirm.status, 400)
const gone = await invoke(routes, 'GET', '/dsh-session-purge/plan?sessionId=session-test-0001')
assert.equal(gone.status, 404)

await rm(home, { recursive: true, force: true })
await rm(projectDir, { recursive: true, force: true })
await rm(projectDirA, { recursive: true, force: true })
await rm(projectDirB, { recursive: true, force: true })
await rm(strayDir, { recursive: true, force: true })
await rm(canaryDir, { recursive: true, force: true })
console.log('self-test OK — plan, tier 1, tier 2, guards all behave as specified')