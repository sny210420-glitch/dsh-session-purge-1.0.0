#!/usr/bin/env node
/**
 * Loads lib/client.js the way the DSH client module loader does (with a
 * stubbed React and DOM) and checks that the bundle exports `apply`/`inject`,
 * registers the sidebar menu item at order 500, and hides itself for
 * non-archived sessions.
 *
 *   node scripts/test-client.mjs
 */
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import vm from 'node:vm'

const here = dirname(fileURLToPath(import.meta.url))
const source = await readFile(join(here, '..', 'lib', 'client.js'), 'utf8')

let captured = null
const registered = []
let archivedIds = []

const react = {
  createElement: (type, props, ...children) => ({ type, props, children }),
  useSyncExternalStore: (subscribe, getSnapshot) => getSnapshot(),
  useState: (initial) => [typeof initial === 'function' ? initial() : initial, () => {}],
  useEffect: () => {},
  Component: class Component {
    constructor(props) {
      this.props = props
    }
  },
  Fragment: Symbol('Fragment'),
}

function makeElement() {
  return {
    setAttribute() {},
    remove() {},
    appendChild() {},
    textContent: '',
  }
}

const documentStub = {
  baseURI: 'http://127.0.0.1:1234/',
  head: { appendChild() {} },
  body: { appendChild() {} },
  createElement: () => makeElement(),
  addEventListener() {},
  removeEventListener() {},
}

const sandbox = {
  window: { __ModuleLoader__: { load: (spec) => { captured = spec } } },
  document: documentStub,
  console,
  URL,
  fetch: async () => ({ ok: true, json: async () => ({}) }),
}
sandbox.globalThis = sandbox

vm.createContext(sandbox)
vm.runInContext(source, sandbox)
assert.ok(captured, 'bundle must call window.__ModuleLoader__.load')
assert.equal(captured.id, 'dsh-session-purge')
assert.equal(typeof captured.factory, 'function')

const modules = {
  react,
  'react-dom/client': { createRoot: () => ({ render() {}, unmount() {} }) },
  '@deepseek-ai/dsh-client-ui-primitives': {
    MenuItemButton: (props) => react.createElement('button', props),
    IconTrashOutlineRegular: () => null,
  },
}
const exports = captured.factory((spec) => {
  if (spec in modules) return modules[spec]
  throw new Error(`unexpected require: ${spec}`)
})

assert.equal(typeof exports.apply, 'function')
assert.deepEqual([...exports.inject], ['slots', 'locale', 'workspaces'])

let dictionaries = null
const ctx = {
  locale: {
    bind: () => (key) => key,
    register: (_ns, value) => {
      dictionaries = value
      return () => {}
    },
  },
  effect: (fn) => {
    const dispose = fn()
    return dispose
  },
  get: (name) => (name === 'workspaces'
    ? {
        list: {
          subscribe: () => () => {},
          getSnapshot: () => ({ archivedSessionIds: archivedIds }),
        },
      }
    : undefined),
  slots: {
    inject: (name, factory) => factory(),
    register: (spec, component) => {
      registered.push({ spec, component })
      return () => {}
    },
  },
}

exports.apply(ctx)
assert.equal(registered.length, 1, 'exactly one slot registration')
const [{ spec, component }] = registered
assert.equal(spec.name, 'sidebar.workspaces.session.menu.item')
assert.equal(spec.id, 'dsh-session-purge.delete')
assert.equal(spec.order, 500)
assert.ok(spec.order > 400, 'must sort after the built-in archive item (400)')
assert.equal(typeof component, 'function')
assert.equal(typeof spec.inject().openPurge, 'function', 'inject face exposes openPurge')
assert.ok(dictionaries && dictionaries.zh && dictionaries.en, 'both dictionaries registered')
assert.deepEqual(Object.keys(dictionaries.zh).sort(), Object.keys(dictionaries.en).sort(), 'dictionaries must share keys')
// Tier 2 must read as a complete deletion that CONTAINS tier 1, never as an add-on.
assert.match(dictionaries.zh['tier.2.desc'], /包含档 1/)
assert.match(dictionaries.en['tier.2.desc'], /contains all of tier 1/)
assert.ok(dictionaries.zh['list.conversation'] && dictionaries.zh['list.artifacts'], 'tier 2 lists conversation + artifacts separately')
// Artifacts are individually selectable, including files outside DSH_HOME.
assert.match(dictionaries.zh['list.artifacts'], /勾选/)
assert.match(dictionaries.en['list.artifacts'], /pick/)
assert.ok(dictionaries.zh['hint.pick'] && dictionaries.en['hint.pick'], 'the pick hint is translated')
assert.ok(!('opt.external' in dictionaries.zh), 'the old include-external opt-in is gone; ticking is the opt-in')
assert.equal(Object.keys(dictionaries.zh).filter((key) => key === 'opt.confirm').length, 1)

// not archived → no menu row
const hidden = component({ sessionId: 'session-x', displayTitle: 'x', t: (key) => key, useMenuOpenState: () => [false, () => {}] })
assert.equal(hidden, null)

// archived → renders a menu item
archivedIds.push('session-x')
const shown = component({ sessionId: 'session-x', displayTitle: 'x', t: (key) => key, useMenuOpenState: () => [false, () => {}] })
assert.ok(shown !== null, 'archived sessions must show the delete item')

console.log('client bundle OK — exports, slot registration, archived gating, dictionaries')