#!/usr/bin/env node
/**
 * Read-only dry run: print exactly what tier 1 / tier 2 would delete.
 *
 *   node scripts/dry-run.mjs <session-id> [--home <DSH_HOME>] [--include-external]
 *
 * Nothing is removed. Use it after archiving a test conversation to confirm
 * the plan before clicking delete in the UI.
 */
import { readFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { buildPlan, isSessionId, resolveDshHome } from '../lib/plan.js'

function takeFlag(name) {
  const index = process.argv.indexOf(name)
  if (index === -1) return undefined
  const value = process.argv[index + 1]
  process.argv.splice(index, value === undefined ? 1 : 2)
  return value
}

const includeExternal = process.argv.includes('--include-external')
const homeArg = takeFlag('--home')
const sessionId = process.argv[2]
const home = resolve(homeArg ? homeArg : resolveDshHome(undefined))
const sessionsRoot = join(home, 'sessions')

if (!sessionId || !isSessionId(sessionId)) {
  console.error('usage: node scripts/dry-run.mjs <session-id> [--home <DSH_HOME>] [--include-external]')
  process.exit(2)
}

function formatBytes(bytes) {
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let value = Number(bytes) || 0
  let index = 0
  while (value >= 1024 && index < units.length - 1) {
    value /= 1024
    index += 1
  }
  return `${value >= 10 || index === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[index]}`
}

async function readArchivedIds() {
  try {
    const raw = await readFile(join(home, 'storages', 'workspace.json'), 'utf8')
    const doc = JSON.parse(raw)
    const candidates = [doc?.archivedSessionIds, doc?.record?.archivedSessionIds, doc?.record?.global?.archivedSessionIds, doc?.global?.archivedSessionIds]
    return candidates.find((value) => Array.isArray(value)) ?? []
  } catch {
    return []
  }
}

const archived = await readArchivedIds()
const plan = await buildPlan({ sessionId, home, sessionsRoot, includeExternalDeliverables: includeExternal })

console.log(`DSH_HOME      ${home}`)
console.log(`session       ${sessionId}`)
console.log(`archived      ${archived.includes(sessionId) ? 'yes' : 'NO (the plugin would refuse this session)'}`)
console.log(`log           ${plan.session.logPath ?? '(not found)'}`)
console.log(`tier 1        ${plan.tier1.length} item(s), ${formatBytes(plan.totals.tier1Bytes)}, ${plan.totals.tier1Files} file(s)`)
for (const entry of plan.tier1) console.log(`  - [${entry.kind}] ${entry.path} ${formatBytes(entry.bytes)}`)
console.log(`artifacts     ${plan.artifacts.length} item(s), ${formatBytes(plan.totals.artifactsBytes)}, ${plan.totals.artifactsFiles} file(s)`)
for (const entry of plan.artifacts) {
  console.log(`  - [${entry.kind}] ${entry.external ? 'EXTERNAL ' : ''}${entry.path} ${formatBytes(entry.bytes)}`)
}
console.log(`tier 2        ${plan.tier2.length} item(s), ${formatBytes(plan.totals.tier2Bytes)}, ${plan.totals.tier2Files} file(s)  (complete deletion = tier 1 + artifacts)`)
for (const entry of plan.tier2) {
  console.log(`  - [${entry.kind}] ${entry.external ? 'EXTERNAL ' : ''}${entry.path} ${formatBytes(entry.bytes)}`)
}
if (plan.warnings.length > 0) {
  console.log('warnings')
  for (const warning of plan.warnings) console.log(`  ! ${warning}`)
}
console.log('\nNothing was deleted (dry run).')