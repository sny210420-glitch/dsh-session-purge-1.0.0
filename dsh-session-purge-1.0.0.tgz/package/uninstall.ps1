﻿<#
  从指定的 DSH profile 卸载 dsh-session-purge。

  用法：
    powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1
    powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1 -Profile desktop
#>
[CmdletBinding()]
param(
  [string]$Profile = "desktop",
  [string]$DshHome = $env:DSH_HOME
)

$ErrorActionPreference = "Stop"
$PackageName = "dsh-session-purge"

if ([string]::IsNullOrWhiteSpace($DshHome)) {
  $DshHome = Join-Path $env:USERPROFILE ".dsh"
}
$DshHome = [IO.Path]::GetFullPath($DshHome)
$profileDir = Join-Path $DshHome "profiles\$Profile"
$manifestPath = Join-Path $profileDir "package.json"

if (-not (Test-Path -LiteralPath $manifestPath)) {
  Write-Host "找不到 $manifestPath，无需卸载。" -ForegroundColor Yellow
  exit 0
}

$backupPath = "$manifestPath.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Copy-Item -LiteralPath $manifestPath -Destination $backupPath -Force
Write-Host "已备份原清单：$backupPath"

$manifest = [IO.File]::ReadAllText($manifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
if ($manifest.dependencies -and ($manifest.dependencies.PSObject.Properties.Name -contains $PackageName)) {
  $manifest.dependencies.PSObject.Properties.Remove($PackageName)
}
if ($manifest.dsh -and $manifest.dsh.profile -and ($manifest.dsh.profile.PSObject.Properties.Name -contains "bundles")) {
  $remaining = @(@($manifest.dsh.profile.bundles) | Where-Object { $_ -ne $PackageName })
  $manifest.dsh.profile | Add-Member -NotePropertyName "bundles" -NotePropertyValue $remaining -Force
}
$json = $manifest | ConvertTo-Json -Depth 32
[IO.File]::WriteAllText($manifestPath, $json, (New-Object System.Text.UTF8Encoding($false)))

foreach ($target in @(
  (Join-Path $profileDir "node_modules\$PackageName"),
  (Join-Path $profileDir "vendor\$PackageName")
)) {
  if (Test-Path -LiteralPath $target) {
    Remove-Item -LiteralPath $target -Recurse -Force
    Write-Host "已删除 $target"
  }
}

Write-Host ""
Write-Host "卸载完成。重启 DSH 桌面端后生效。" -ForegroundColor Green
Write-Host "已删除的对话与产物不会因为卸载而恢复。"