# dsh-session-purge

给 DSH 的「已归档会话」加一个真正的删除入口。DSH 自己只会归档，归档之后日志、缓存、附件仍然留在硬盘上；这个插件负责把它们清干净。

## 两档删除

| 档位 | 删什么 | 不删什么 |
| --- | --- | --- |
| 档 1 · 仅删除对话记录 | 会话日志（`$DSH_HOME/sessions/.../<id>/`）、会话列表与摘要缓存、归档/置顶/工作区记账、以该会话 id 命名的 DSH 记录 | 附件、临时文件、对话生成的文件 |
| 档 2 · 完全删除 | 档 1 的全部内容 **加上** 该对话产生的产物：独占附件对象、spill 临时文件、`present` 过的交付文件、项目目录里它生成的文件 | 其它会话共享的附件、项目源码、全局日志 |

档 2 是档 1 的**超集**：点档 2 一次就把两边都删掉，不需要先删档 1。

产物在档 2 里逐项列出、可以勾选。默认勾选规则：

- 会话期间新建、且对话在工具调用里点过名的文档（Word / Excel / PPT / PDF / 图片 / 媒体 / 压缩包）默认勾上；
- 会话期间新建但对话没提过的文档默认列出但**不勾**（可能是你自己放进去的）；
- 其它目录里的文件、代码文件（`.py` / `.js` / `.md` …）一律默认不勾。

## 安装

### 方式一：一键脚本（Windows，推荐）

1. 解压下载到的压缩包；
2. 右键 `install.ps1` → **使用 PowerShell 运行**；如果被策略拦住，在该目录打开 PowerShell 执行：

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
   ```

3. 脚本会把插件放进 profile 的 `vendor` 与 `node_modules`，登记依赖和 bundle，然后提示你重启 DSH 桌面端。

指定 profile（默认 `desktop`）：`.\install.ps1 -Profile desktop`。

### 方式二：命令行

```powershell
dsh plugin --profile desktop add "file:C:\path\to\dsh-session-purge-1.0.0.tgz"
```

DSH 桌面端运行时可能拒绝直接写 `desktop` profile，此时请先退出应用，或在脚本方式下安装。

### 方式三：手动

1. 把解压出的 `dsh-session-purge` 目录复制到 `<DSH_HOME>\profiles\<profile>\vendor\dsh-session-purge`，再复制一份到同目录下的 `node_modules\dsh-session-purge`；
2. 编辑 `<profile>\package.json`：
   - `dependencies` 里加 `"dsh-session-purge": "file:./vendor/dsh-session-purge"`；
   - `dsh.profile.bundles` 数组末尾加 `"dsh-session-purge"`；
3. 重启 DSH 桌面端。

`DSH_HOME` 默认是 `C:\Users\<你>\.dsh`。

## 使用

1. 在侧栏把对话归档（视图切到「已归档」可以看到它）；
2. 点该行右侧的「⋯」→ 归档项下方的 **删除对话…**；
3. 选档位：档 1 只清对话，档 2 清对话加产物；
4. 档 2 里核对产物列表，取消勾选你不想删的项；
5. 勾选「我明白此操作不可撤销」→ 确认。

删除后该行会立即从侧栏消失，不需要刷新。运行中的对话不能删——先等它结束，或点归档时让 DSH 停掉当前回合。

## 安全边界

- 只删能证明属于该会话的东西：日志目录、以会话 id 命名的记录、日志里引用过的附件（且没有别的会话引用）、`present` 记录的文件、会话期间在项目目录里新建的文件。
- 每个待删路径都会校验父目录，拒绝盘根、`C:\Windows`、`Program Files` 以及 `..` 逃逸。
- 不碰项目源码目录里的已有文件、不碰全局日志、不碰其它会话的附件。
- 附件按 sha256 引用计数：只要还有别的会话引用，就保留。

## 卸载

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1
```

或手动：从 `dependencies` 与 `dsh.profile.bundles` 移除 `dsh-session-purge`，删掉 `vendor\dsh-session-purge` 与 `node_modules\dsh-session-purge`，重启。

## 从源码使用

```
lib/plan.js      纯逻辑：枚举、计量、引用计数、路径校验、执行删除
lib/index.js     宿主插件：两条 HTTP 路由 /dsh-session-purge/plan 与 /delete
lib/client.js    客户端 bundle：会话菜单项 + 删除弹窗
scripts/         自测与只读排查脚本
```

- `node scripts/test-routes.mjs`：路由、两档、勾选、守卫的自测（在临时 home 里跑）
- `node scripts/test-client.mjs`：客户端 bundle 的导出与 slot 注册自测
- `node scripts/show-plan.mjs <session-id>`：只读打印某会话两档会删什么
- `node scripts/sweep-orphans.mjs`：清理历史遗留的孤儿附件（默认 dry-run，`--apply` 才删）

## 许可证

MIT