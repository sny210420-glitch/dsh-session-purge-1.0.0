# 发布到 DSH 插件市场

## 先弄清市场的机制

DSH 的插件市场**没有中心化上传入口**，也不是一个应用商店。它是：

```
你的索引 JSON（一个 https 地址）  →  DSH 的「发现」页读取  →  点安装  →  按索引里的描述去 npm 或 git 取包
```

所以「上架」＝ 两件事：

1. 把包放到别人装得到的地方：**npm registry** 或 **公开 Git 仓库**；
2. 托管一份索引 JSON，把它的 URL 告诉用户（用户在 DSH 里：设置 → 插件市场 → 添加索引源）。

索引格式由 `@deepseek-ai/dsh-plugin-market-index` 校验（format 1），本目录的两个示例都通过了官方校验器。

## 方案 A：发到 npm（推荐，用户一条命令就能装）

```powershell
cd <插件源码目录>
# 如果 dsh-session-purge 这个名字在 npm 上已被占用，先改成带 scope 的：
#   "name": "@你的名字/dsh-session-purge"
npm login
npm publish --access public
```

然后生成索引：

```powershell
node scripts/make-index.mjs --source npm --published <当前Unix秒> --out market/index.json
```

把 `market/index.json` 放到任何 https 静态托管上（GitHub Pages、Gitee Pages、对象存储、你自己的域名都行），
把该 URL 加进 DSH 的设置 → 插件市场 → 索引源。

## 方案 B：放 GitHub（不用 npm 账号）

```powershell
cd <插件源码目录>
git init; git add -A; git commit -m "dsh-session-purge 1.0.0"
git remote add origin https://github.com/<你>/dsh-session-purge.git
git push -u origin main
git rev-parse HEAD   # 记下这 40 位 commit
```

生成索引（git 源必须钉到具体 commit）：

```powershell
node scripts/make-index.mjs --source git `
  --repo https://github.com/<你>/dsh-session-purge `
  --commit <40位commit> --published <当前Unix秒> --out market/index.json
```

托管 `market/index.json`：最简单是把它放进仓库的 `docs/`，开 GitHub Pages，索引 URL 形如
`https://<你>.github.io/dsh-session-purge/index.json`。也可以用仓库 raw 地址（`raw.githubusercontent.com`）。

注意：git 源装的是仓库内容，用户机器上会执行 `pnpm add git+https://...#<commit>`，
所以仓库里必须是**已构建好**的包（`lib/` 要在仓库里，不能只提交 `src/`）。

## 方案 C：只发压缩包（不做市场）

压缩包里的 `install.ps1` 已经把「复制文件 + 改 profile 清单」都做好了，用户双击脚本就能用。
这条路径不依赖 npm、GitHub 或任何托管，适合先在群里发一版。

## 索引里能写什么

| 字段 | 说明 |
| --- | --- |
| `format` | 固定 `1` |
| `title` / `description` | 索引自己的名字；`{ "en": "...", "zh": "..." }` 形式时必须有 `en` |
| `plugins[].name` | npm 包名，必须与 `package.json` 的 `name` 一致 |
| `plugins[].versions[]` | 每个版本一条：`version`、`publishTimestamp`（Unix 秒）、`source` |
| `source.type` | `npm`（可带 `registry`）或 `git`（`url` + 40 位 `commit`，可带子目录 `path`） |
| `metadata.category` / `labels` / `keywords` | 分类、标签、搜索关键词 |

一份索引可以列多个插件、每个插件多个版本；DSH 取「最高且兼容当前 DSH 版本」的那个。
插件若在 `package.json` 里声明了 `engines.dsh`，不满足的版本会被标成不兼容并拒绝安装——本插件没有声明，
因此对所有 DSH 版本都显示可安装（插件依赖的 `webServer` / `workspaceRegistry` / `slots` 等接口在 0.2.x 上稳定）。

## 更新版本

1. 改 `package.json` 的 `version`（例如 `1.0.1`），重新 `npm publish` 或推一个新 commit；
2. 在索引的 `versions` 数组里**追加**一条（不要删旧的），重新生成/托管；
3. 用户重新打开发现页就能看到新版本。